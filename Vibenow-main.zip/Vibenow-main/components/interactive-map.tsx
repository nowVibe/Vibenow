"use client"

import { useEffect, useRef, useState, useCallback } from "react"
import { MapPin, Star, Clock, Users, Navigation, Layers } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { cityCoordinates } from "@/lib/events"

interface Event {
  id: number
  title: string
  date: string
  time: string
  location: string
  city: string
  genre: string
  category: string
  price?: string
  capacity?: string
  rating?: number
  featured?: boolean
  lat: number
  lng: number
}

interface InteractiveMapProps {
  events: Event[]
  selectedCategory: string
  selectedGenre: string
  selectedCity: string
  onEventSelect?: (eventId: number) => void
}

// Coordinate delle città italiane per il centro mappa
// const cityCoordinates: { [key: string]: { lat: number; lng: number; zoom: number } } = {
//   Milano: { lat: 45.4642, lng: 9.19, zoom: 11 },
//   Roma: { lat: 41.9028, lng: 12.4964, zoom: 11 },
//   Napoli: { lat: 40.8518, lng: 14.2681, zoom: 11 },
//   Torino: { lat: 45.0703, lng: 7.6869, zoom: 11 },
//   Firenze: { lat: 43.7696, lng: 11.2558, zoom: 12 },
//   Bologna: { lat: 44.4949, lng: 11.3426, zoom: 12 },
//   Catania: { lat: 37.5079, lng: 15.083, zoom: 12 },
//   Riccione: { lat: 44.0058, lng: 12.6553, zoom: 13 },
//   "Milano Marittima": { lat: 44.2897, lng: 12.3468, zoom: 13 },
//   Positano: { lat: 40.628, lng: 14.4897, zoom: 14 },
//   Sanremo: { lat: 43.8167, lng: 7.7667, zoom: 13 },
//   Venezia: { lat: 45.4408, lng: 12.3155, zoom: 12 },
//   Palermo: { lat: 38.1157, lng: 13.3613, zoom: 11 },
// }

// Icone personalizzate per categoria
const getCategoryIcon = (category: string, featured = false) => {
  const icons: { [key: string]: string } = {
    Nightclub: "🎵",
    "Beach Club": "🏖️",
    Rooftop: "🏙️",
    Aperitivo: "🍸",
    "Live Music": "🎤",
    Sport: "⚽",
    "Pool Party": "🏊",
    Comedy: "😂",
    Karaoke: "🎙️",
  }

  return {
    icon: icons[category] || "🎉",
    color: featured ? "#fbbf24" : "#eab308",
    size: featured ? 40 : 30,
  }
}

// Funzione per creare HTML del marker personalizzato
const createCustomMarkerHTML = (event: Event) => {
  const { icon, color, size } = getCategoryIcon(event.category, event.featured)

  return `
    <div style="
      width: ${size}px;
      height: ${size}px;
      background: ${event.featured ? "linear-gradient(135deg, #fbbf24, #f59e0b)" : "#1e293b"};
      border: 2px solid ${color};
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: ${size * 0.5}px;
      cursor: pointer;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
      transition: all 0.3s ease;
      position: relative;
      ${event.featured ? "box-shadow: 0 0 20px rgba(251, 191, 36, 0.6);" : ""}
    " 
    onmouseover="this.style.transform='scale(1.2)'"
    onmouseout="this.style.transform='scale(1)'"
    title="${event.title}">
      ${icon}
      ${event.featured ? '<div style="position: absolute; top: -5px; right: -5px; width: 12px; height: 12px; background: #ef4444; border-radius: 50%; border: 2px solid white;"></div>' : ""}
    </div>
  `
}

export default function InteractiveMap({
  events,
  selectedCategory,
  selectedGenre,
  selectedCity,
  onEventSelect,
}: InteractiveMapProps) {
  const mapRef = useRef<HTMLDivElement>(null)
  const leafletMapRef = useRef<any>(null)
  const markersRef = useRef<any[]>([])
  const layersRef = useRef<{ street: any; satellite: any }>({ street: null, satellite: null })
  const initializationRef = useRef(false)

  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null)
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null)
  const [mapStyle, setMapStyle] = useState<"street" | "satellite">("street")
  const [leafletLoaded, setLeafletLoaded] = useState(false)

  // Filtra eventi (memoized to prevent re-renders)
  const filteredEvents = events.filter((event) => {
    const matchesCategory = selectedCategory === "Tutte" || event.category === selectedCategory
    const matchesGenre = selectedGenre === "Tutti" || event.genre === selectedGenre
    const matchesCity = selectedCity === "Tutte" || event.city === selectedCity
    return matchesCategory && matchesGenre && matchesCity
  })

  // Load Leaflet library only once
  useEffect(() => {
    if (leafletLoaded || initializationRef.current) return

    initializationRef.current = true

    const loadLeaflet = async () => {
      try {
        // Load CSS
        if (!document.querySelector('link[href*="leaflet"]')) {
          const link = document.createElement("link")
          link.rel = "stylesheet"
          link.href = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
          document.head.appendChild(link)
        }

        // Load JS
        if (!(window as any).L) {
          await new Promise((resolve, reject) => {
            const script = document.createElement("script")
            script.src = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
            script.onload = resolve
            script.onerror = reject
            document.head.appendChild(script)
          })
        }

        setLeafletLoaded(true)
      } catch (error) {
        console.error("Error loading Leaflet:", error)
        initializationRef.current = false
      }
    }

    loadLeaflet()
  }, [leafletLoaded])

  // Initialize map only once when Leaflet is loaded
  useEffect(() => {
    if (!leafletLoaded || !mapRef.current || leafletMapRef.current) return

    const L = (window as any).L
    if (!L) return

    try {
      // Create map
      const map = L.map(mapRef.current, {
        zoomControl: false,
        attributionControl: false,
      }).setView([41.8719, 12.5674], 6) // Centro Italia

      // Create layers
      const streetLayer = L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19,
      })

      const satelliteLayer = L.tileLayer(
        "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
        {
          maxZoom: 19,
        },
      )

      // Add default layer
      streetLayer.addTo(map)

      // Store references
      leafletMapRef.current = map
      layersRef.current = { street: streetLayer, satellite: satelliteLayer }

      // Add zoom control
      const zoomControl = L.control.zoom({
        position: "bottomright",
      })
      zoomControl.addTo(map)
    } catch (error) {
      console.error("Error initializing map:", error)
    }
  }, [leafletLoaded])

  // Clear markers function
  const clearMarkers = useCallback(() => {
    if (!leafletMapRef.current) return

    markersRef.current.forEach((marker) => {
      try {
        leafletMapRef.current.removeLayer(marker)
      } catch (error) {
        console.error("Error removing marker:", error)
      }
    })
    markersRef.current = []
  }, [])

  // Update markers when filtered events change
  useEffect(() => {
    if (!leafletMapRef.current || !leafletLoaded) return

    const L = (window as any).L
    if (!L) return

    clearMarkers()

    try {
      // Add event markers
      filteredEvents.forEach((event) => {
        const customIcon = L.divIcon({
          html: createCustomMarkerHTML(event),
          className: "custom-marker",
          iconSize: [
            getCategoryIcon(event.category, event.featured).size,
            getCategoryIcon(event.category, event.featured).size,
          ],
          iconAnchor: [
            getCategoryIcon(event.category, event.featured).size / 2,
            getCategoryIcon(event.category, event.featured).size / 2,
          ],
        })

        const marker = L.marker([event.lat, event.lng], { icon: customIcon })
          .addTo(leafletMapRef.current)
          .on("click", () => {
            if (onEventSelect) {
              // Scroll to the event card in the list
              onEventSelect(event.id)
            } else {
              // Fallback to popup if no callback provided
              setSelectedEvent(event)
            }
          })

        markersRef.current.push(marker)
      })

      // Add user location marker
      if (userLocation) {
        const userIcon = L.divIcon({
          html: `
            <div style="
              width: 20px;
              height: 20px;
              background: #3b82f6;
              border: 3px solid white;
              border-radius: 50%;
              box-shadow: 0 2px 8px rgba(0,0,0,0.3);
              animation: pulse 2s infinite;
            "></div>
            <style>
              @keyframes pulse {
                0% { box-shadow: 0 0 0 0 rgba(59, 130, 246, 0.7); }
                70% { box-shadow: 0 0 0 10px rgba(59, 130, 246, 0); }
                100% { box-shadow: 0 0 0 0 rgba(59, 130, 246, 0); }
              }
            </style>
          `,
          className: "user-location-marker",
          iconSize: [20, 20],
          iconAnchor: [10, 10],
        })

        const userMarker = L.marker([userLocation.lat, userLocation.lng], { icon: userIcon })
          .addTo(leafletMapRef.current)
          .bindPopup("La tua posizione")

        markersRef.current.push(userMarker)
      }

      // Fit bounds to show all markers
      if (filteredEvents.length > 0) {
        const eventMarkers = markersRef.current.filter((marker) => marker.getLatLng && !marker.options.isUserLocation)
        if (eventMarkers.length > 0) {
          const group = new L.featureGroup(eventMarkers)
          if (group.getBounds().isValid()) {
            leafletMapRef.current.fitBounds(group.getBounds(), { padding: [20, 20] })
          }
        }
      }
    } catch (error) {
      console.error("Error updating markers:", error)
    }
  }, [filteredEvents, userLocation, leafletLoaded, clearMarkers, onEventSelect])

  // Get user location
  const getUserLocation = useCallback(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const newLocation = {
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          }
          setUserLocation(newLocation)

          // Center map on user location
          if (leafletMapRef.current) {
            leafletMapRef.current.setView([newLocation.lat, newLocation.lng], 12)
          }
        },
        (error) => {
          console.log("Geolocation error:", error)
        },
      )
    }
  }, [])

  // Toggle map style
  const toggleMapStyle = useCallback(() => {
    if (!leafletMapRef.current || !layersRef.current.street || !layersRef.current.satellite) return

    const map = leafletMapRef.current
    const { street, satellite } = layersRef.current
    const newStyle = mapStyle === "street" ? "satellite" : "street"

    try {
      if (newStyle === "satellite") {
        map.removeLayer(street)
        map.addLayer(satellite)
      } else {
        map.removeLayer(satellite)
        map.addLayer(street)
      }

      setMapStyle(newStyle)
    } catch (error) {
      console.error("Error toggling map style:", error)
    }
  }, [mapStyle])

  // Center map on selected city
  useEffect(() => {
    if (!leafletMapRef.current || selectedCity === "Tutte") return

    const cityCoord = cityCoordinates[selectedCity]
    if (cityCoord) {
      try {
        leafletMapRef.current.setView([cityCoord.lat, cityCoord.lng], cityCoord.zoom)
      } catch (error) {
        console.error("Error centering on city:", error)
      }
    }
  }, [selectedCity])

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (leafletMapRef.current) {
        try {
          leafletMapRef.current.remove()
          leafletMapRef.current = null
        } catch (error) {
          console.error("Error cleaning up map:", error)
        }
      }
    }
  }, [])

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("it-IT", {
      weekday: "short",
      day: "numeric",
      month: "short",
    })
  }

  return (
    <div className="relative w-full h-[500px] rounded-2xl overflow-hidden border-2 border-yellow-400/30 shadow-2xl shadow-yellow-400/10">
      {/* Map */}
      <div ref={mapRef} className="w-full h-full" />

      {/* Loading overlay */}
      {!leafletLoaded && (
        <div className="absolute inset-0 bg-slate-800 flex items-center justify-center">
          <div className="text-center">
            <div className="w-8 h-8 border-4 border-yellow-400/30 border-t-yellow-400 rounded-full animate-spin mx-auto mb-4"></div>
            <div className="text-yellow-400 font-semibold">Caricamento mappa...</div>
          </div>
        </div>
      )}

      {/* Map controls */}
      <div className="absolute top-4 left-4 flex flex-col gap-2">
        <Button
          size="sm"
          variant="outline"
          className="bg-slate-900/90 border-yellow-400/50 text-yellow-400 backdrop-blur-sm hover:bg-yellow-400/10"
          onClick={getUserLocation}
          disabled={!leafletLoaded}
        >
          <Navigation className="w-4 h-4 mr-1" />
          La mia posizione
        </Button>

        <Button
          size="sm"
          variant="outline"
          className="bg-slate-900/90 border-yellow-400/50 text-yellow-400 backdrop-blur-sm hover:bg-yellow-400/10"
          onClick={toggleMapStyle}
          disabled={!leafletLoaded}
        >
          <Layers className="w-4 h-4 mr-1" />
          {mapStyle === "street" ? "Satellite" : "Stradale"}
        </Button>
      </div>

      {/* Legend */}
      <div className="absolute top-4 right-4 bg-slate-900/95 backdrop-blur-sm rounded-lg p-3 border border-yellow-400/30">
        <h4 className="text-yellow-400 font-semibold text-sm mb-2">Legenda</h4>
        <div className="space-y-1">
          {["Nightclub", "Beach Club", "Rooftop", "Aperitivo"].map((category) => {
            const { icon } = getCategoryIcon(category)
            return (
              <div key={category} className="flex items-center gap-2 text-xs text-slate-300">
                <span className="text-sm">{icon}</span>
                <span>{category}</span>
              </div>
            )
          })}
          <div className="flex items-center gap-2 text-xs text-slate-300">
            <div className="w-3 h-3 bg-gradient-to-r from-yellow-400 to-amber-500 rounded-full"></div>
            <span>Featured</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-slate-300">
            <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
            <span>La tua posizione</span>
          </div>
        </div>
      </div>

      {/* Statistics */}
      <div className="absolute bottom-4 left-4 bg-slate-900/95 backdrop-blur-sm rounded-lg p-3 border border-yellow-400/30">
        <div className="text-yellow-400 font-semibold text-sm">{filteredEvents.length} eventi trovati</div>
        {selectedCity !== "Tutte" && <div className="text-slate-300 text-xs">in {selectedCity}</div>}
      </div>

      {/* Event popup */}
      {selectedEvent && (
        <div className="absolute inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <Card className="w-full max-w-md bg-slate-800 border-yellow-400/30">
            <CardContent className="p-6">
              <div className="flex justify-between items-start mb-4">
                <h3 className="text-xl font-bold text-white">{selectedEvent.title}</h3>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setSelectedEvent(null)}
                  className="text-slate-400 hover:text-white"
                >
                  ✕
                </Button>
              </div>

              <div className="space-y-3">
                <div className="flex items-center gap-2 text-slate-300">
                  <Clock className="w-4 h-4 text-yellow-400" />
                  <span className="text-sm">
                    {formatDate(selectedEvent.date)} • {selectedEvent.time}
                  </span>
                </div>

                <div className="flex items-center gap-2 text-slate-300">
                  <MapPin className="w-4 h-4 text-yellow-400" />
                  <span className="text-sm">
                    {selectedEvent.location}, {selectedEvent.city}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <Badge variant="secondary" className="bg-slate-700 text-yellow-400 border-yellow-400/30">
                    {selectedEvent.category}
                  </Badge>
                  <Badge variant="outline" className="border-slate-600 text-slate-300">
                    {selectedEvent.genre}
                  </Badge>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <div className="flex items-center gap-4">
                    {selectedEvent.price && (
                      <span className="text-yellow-400 font-bold text-lg">{selectedEvent.price}</span>
                    )}
                    {selectedEvent.rating && (
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 text-yellow-400 fill-current" />
                        <span className="text-sm text-slate-300">{selectedEvent.rating}</span>
                      </div>
                    )}
                  </div>
                  {selectedEvent.capacity && (
                    <div className="flex items-center gap-1 text-slate-400">
                      <Users className="w-4 h-4" />
                      <span className="text-xs">{selectedEvent.capacity}</span>
                    </div>
                  )}
                </div>

                <div className="flex gap-2 pt-4">
                  <Button className="flex-1 bg-yellow-400 hover:bg-yellow-500 text-slate-900 font-bold">
                    Prenota Ora
                  </Button>
                  <Button
                    variant="outline"
                    className="border-yellow-400/50 text-yellow-400 hover:bg-yellow-400/10"
                    onClick={() => {
                      window.open(`https://maps.google.com/?q=${selectedEvent.lat},${selectedEvent.lng}`, "_blank")
                    }}
                  >
                    <Navigation className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
