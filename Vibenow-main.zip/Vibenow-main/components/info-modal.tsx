"use client"

import type React from "react"
import { useState } from "react"
import { X, Calendar, MapPin, Clock, Mail, User, Phone } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Card, CardContent } from "@/components/ui/card"

interface Event {
  id: number
  title: string
  date: string
  time: string
  location: string
  city: string
  category: string
  genre: string
}

interface InfoModalProps {
  isOpen: boolean
  onClose: () => void
  event: Event
}

export default function InfoModal({ isOpen, onClose, event }: InfoModalProps) {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    agreeUpdates: false,
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)

  if (!isOpen) return null

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("it-IT", {
      weekday: "long",
      day: "numeric",
      month: "long",
    })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      // Simula invio dati (senza database per ora)
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Simula successo
      console.log("Dati raccolti:", {
        eventId: event.id,
        eventTitle: event.title,
        firstName: formData.firstName,
        lastName: formData.lastName,
        email: formData.email,
        phone: formData.phone,
      })

      setIsSuccess(true)
    } catch (error) {
      console.error("Errore:", error)
      alert("Errore durante l'invio. Riprova.")
    } finally {
      setIsSubmitting(false)
    }
  }

  const resetAndClose = () => {
    setFormData({
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      agreeUpdates: false,
    })
    setIsSuccess(false)
    onClose()
  }

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-lg bg-slate-800 border-yellow-400/30 max-h-[90vh] overflow-y-auto">
        <CardContent className="p-0">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-slate-700">
            <div>
              <h2 className="text-2xl font-bold text-white">{isSuccess ? "Richiesta inviata!" : "Più Informazioni"}</h2>
              <p className="text-slate-400">{event.title}</p>
            </div>
            <Button variant="ghost" size="sm" onClick={resetAndClose} className="text-slate-400 hover:text-white">
              <X className="w-5 h-5" />
            </Button>
          </div>

          {/* Event Summary */}
          <div className="p-6 bg-slate-900/30">
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-slate-300">
                <Calendar className="w-4 h-4 text-yellow-400" />
                <span className="text-sm">{formatDate(event.date)}</span>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <Clock className="w-4 h-4 text-yellow-400" />
                <span className="text-sm">{event.time}</span>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <MapPin className="w-4 h-4 text-yellow-400" />
                <span className="text-sm">
                  {event.location}, {event.city}
                </span>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="p-6">
            {!isSuccess ? (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="text-center mb-6">
                  <h3 className="text-lg font-semibold text-white mb-2">Ricevi aggiornamenti su questo evento</h3>
                  <p className="text-slate-300 text-sm">
                    Lascia i tuoi contatti per ricevere tutte le novità, orari aggiornati e informazioni speciali
                    sull'evento.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="firstName" className="text-white flex items-center gap-2">
                      <User className="w-4 h-4" />
                      Nome *
                    </Label>
                    <Input
                      id="firstName"
                      value={formData.firstName}
                      onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                      className="bg-slate-700 border-slate-600 text-white"
                      placeholder="Il tuo nome"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="lastName" className="text-white flex items-center gap-2">
                      <User className="w-4 h-4" />
                      Cognome *
                    </Label>
                    <Input
                      id="lastName"
                      value={formData.lastName}
                      onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                      className="bg-slate-700 border-slate-600 text-white"
                      placeholder="Il tuo cognome"
                      required
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="email" className="text-white flex items-center gap-2">
                    <Mail className="w-4 h-4" />
                    Email *
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="bg-slate-700 border-slate-600 text-white"
                    placeholder="la-tua-email@esempio.com"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="phone" className="text-white flex items-center gap-2">
                    <Phone className="w-4 h-4" />
                    Telefono
                  </Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="bg-slate-700 border-slate-600 text-white"
                    placeholder="+39 123 456 7890"
                  />
                </div>

                <div className="flex items-start space-x-2">
                  <Checkbox
                    id="updates"
                    checked={formData.agreeUpdates}
                    onCheckedChange={(checked) => setFormData({ ...formData, agreeUpdates: checked as boolean })}
                  />
                  <Label htmlFor="updates" className="text-sm text-slate-300 leading-relaxed">
                    Accetto di ricevere aggiornamenti via email su questo evento e future comunicazioni da VibeNow
                  </Label>
                </div>

                <Button
                  type="submit"
                  className="w-full bg-yellow-400 hover:bg-yellow-500 text-slate-900 font-bold"
                  disabled={
                    !formData.firstName ||
                    !formData.lastName ||
                    !formData.email ||
                    !formData.agreeUpdates ||
                    isSubmitting
                  }
                >
                  {isSubmitting ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-slate-900/30 border-t-slate-900 rounded-full animate-spin" />
                      Invio in corso...
                    </div>
                  ) : (
                    <>
                      <Mail className="w-4 h-4 mr-2" />
                      Ricevi Aggiornamenti
                    </>
                  )}
                </Button>
              </form>
            ) : (
              <div className="text-center space-y-6">
                <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto">
                  <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>

                <div>
                  <h3 className="text-2xl font-bold text-white mb-2">Perfetto!</h3>
                  <p className="text-slate-300">
                    Riceverai tutte le novità e gli aggiornamenti su{" "}
                    <span className="text-yellow-400 font-semibold">{event.title}</span> all'indirizzo{" "}
                    <span className="text-yellow-400">{formData.email}</span>
                  </p>
                </div>

                <div className="bg-slate-900/50 rounded-lg p-4">
                  <h4 className="font-bold text-white mb-2">📧 Cosa riceverai:</h4>
                  <ul className="text-sm text-slate-300 space-y-1 text-left">
                    <li>• Aggiornamenti su orari e location</li>
                    <li>• Informazioni sui biglietti e prenotazioni</li>
                    <li>• Novità su artisti e lineup</li>
                    <li>• Offerte speciali e sconti esclusivi</li>
                  </ul>
                </div>

                <Button
                  onClick={resetAndClose}
                  className="w-full bg-yellow-400 hover:bg-yellow-500 text-slate-900 font-bold"
                >
                  Perfetto!
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
