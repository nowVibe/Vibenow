"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { Calendar, MapPin, Clock, Users, Star, ArrowLeft, Share2, Heart, Navigation, Info } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import InfoModal from "@/components/info-modal"

import { getEventById } from "@/lib/events"
import type { Event } from "@/lib/events"

export default function EventDetailPage() {
  const params = useParams()
  const router = useRouter()
  const [event, setEvent] = useState<Event | null>(null)
  const [isInfoModalOpen, setIsInfoModalOpen] = useState(false)
  const [isFavorite, setIsFavorite] = useState(false)

  useEffect(() => {
    const eventId = Number.parseInt(params.id as string)
    const foundEvent = getEventById(eventId)
    setEvent(foundEvent || null)
  }, [params.id])

  if (!event) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-yellow-400/30 border-t-yellow-400 rounded-full animate-spin mx-auto mb-4"></div>
          <div className="text-yellow-400 font-semibold">Caricamento evento...</div>
        </div>
      </div>
    )
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("it-IT", {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric",
    })
  }

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: event.title,
          text: `Scopri questo evento su VibeNow: ${event.title}`,
          url: window.location.href,
        })
      } catch (error) {
        console.log("Errore condivisione:", error)
      }
    } else {
      // Fallback: copia URL
      navigator.clipboard.writeText(window.location.href)
      alert("Link copiato negli appunti!")
    }
  }

  const openInMaps = () => {
    window.open(`https://maps.google.com/?q=${event.lat},${event.lng}`, "_blank")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Header */}
      <header className="sticky top-0 z-50 backdrop-blur-xl bg-slate-950/80 border-b border-yellow-400/20">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              onClick={() => router.back()}
              className="text-yellow-400 hover:text-yellow-300 hover:bg-yellow-400/10"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Torna indietro
            </Button>

            <div className="text-2xl font-black tracking-wider">
              <span className="bg-gradient-to-r from-yellow-300 via-yellow-400 to-amber-400 bg-clip-text text-transparent">
                VIBENOW
              </span>
            </div>

            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsFavorite(!isFavorite)}
                className="text-slate-400 hover:text-red-400"
              >
                <Heart className={`w-4 h-4 ${isFavorite ? "fill-red-400 text-red-400" : ""}`} />
              </Button>
              <Button variant="ghost" size="sm" onClick={handleShare} className="text-slate-400 hover:text-yellow-400">
                <Share2 className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative h-96 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-yellow-400/20 via-slate-800 to-slate-900" />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/50 to-transparent" />

        {event.featured && (
          <div className="absolute top-6 right-6 z-10">
            <Badge className="bg-yellow-400 text-slate-900 font-bold text-lg px-4 py-2">
              <Star className="w-4 h-4 mr-2" />
              Featured Event
            </Badge>
          </div>
        )}

        <div className="relative h-full flex items-end">
          <div className="container mx-auto px-4 pb-12">
            <div className="max-w-4xl">
              <div className="flex items-center gap-3 mb-4">
                <Badge variant="secondary" className="bg-slate-700 text-yellow-400 border-yellow-400/30">
                  {event.category}
                </Badge>
                <Badge variant="outline" className="border-slate-600 text-slate-300">
                  {event.genre}
                </Badge>
              </div>

              <h1 className="text-4xl md:text-6xl font-black text-white mb-4 leading-tight">{event.title}</h1>

              <div className="flex flex-wrap items-center gap-6 text-slate-300">
                <div className="flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-yellow-400" />
                  <span className="font-medium">{formatDate(event.date)}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-5 h-5 text-yellow-400" />
                  <span>{event.time}</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-yellow-400" />
                  <span>
                    {event.location}, {event.city}
                  </span>
                </div>
                {event.rating && (
                  <div className="flex items-center gap-2">
                    <Star className="w-5 h-5 text-yellow-400 fill-current" />
                    <span className="font-medium">{event.rating}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Content */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-8">
              {/* Description */}
              <Card className="bg-slate-800 border-slate-700">
                <CardContent className="p-6">
                  <h2 className="text-2xl font-bold text-white mb-4">Descrizione Evento</h2>
                  <p className="text-slate-300 leading-relaxed text-lg">{event.description}</p>
                </CardContent>
              </Card>

              {/* Highlights */}
              {event.highlights && (
                <Card className="bg-slate-800 border-slate-700">
                  <CardContent className="p-6">
                    <h2 className="text-2xl font-bold text-white mb-4">Highlights</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {event.highlights.map((highlight, index) => (
                        <div key={index} className="flex items-center gap-3">
                          <div className="w-2 h-2 bg-yellow-400 rounded-full" />
                          <span className="text-slate-300">{highlight}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Location Map */}
              <Card className="bg-slate-800 border-slate-700">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-2xl font-bold text-white">Posizione</h2>
                    <Button
                      variant="outline"
                      onClick={openInMaps}
                      className="border-yellow-400/50 text-yellow-400 hover:bg-yellow-400/10"
                    >
                      <Navigation className="w-4 h-4 mr-2" />
                      Apri in Maps
                    </Button>
                  </div>
                  <div className="bg-slate-700 rounded-lg h-64 flex items-center justify-center">
                    <div className="text-center text-slate-400">
                      <MapPin className="w-12 h-12 mx-auto mb-2" />
                      <p className="font-medium">{event.location}</p>
                      <p className="text-sm">{event.city}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Info Card */}
              <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-yellow-400/30 sticky top-24">
                <CardContent className="p-6">
                  <div className="text-center mb-6">
                    {event.price && <div className="text-4xl font-black text-yellow-400 mb-2">{event.price}</div>}
                    <p className="text-slate-400">per persona</p>
                  </div>

                  <Button
                    onClick={() => setIsInfoModalOpen(true)}
                    className="w-full bg-yellow-400 hover:bg-yellow-500 text-slate-900 font-bold text-lg py-3 mb-4"
                  >
                    <Info className="w-4 h-4 mr-2" />
                    Più Informazioni
                  </Button>

                  <Separator className="bg-slate-700 mb-4" />

                  <div className="space-y-3 text-sm">
                    {event.organizer && (
                      <div className="flex justify-between">
                        <span className="text-slate-400">Organizzatore:</span>
                        <span className="text-white font-medium">{event.organizer}</span>
                      </div>
                    )}
                    {event.capacity && (
                      <div className="flex justify-between">
                        <span className="text-slate-400">Capacità:</span>
                        <span className="text-white font-medium">{event.capacity} persone</span>
                      </div>
                    )}
                    {event.ageLimit && (
                      <div className="flex justify-between">
                        <span className="text-slate-400">Età minima:</span>
                        <span className="text-white font-medium">{event.ageLimit}</span>
                      </div>
                    )}
                    {event.dresscode && (
                      <div className="flex justify-between">
                        <span className="text-slate-400">Dress code:</span>
                        <span className="text-white font-medium">{event.dresscode}</span>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Quick Info */}
              <Card className="bg-slate-800 border-slate-700">
                <CardContent className="p-6">
                  <h3 className="text-lg font-bold text-white mb-4">Informazioni Rapide</h3>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <Users className="w-5 h-5 text-yellow-400" />
                      <div>
                        <p className="text-white font-medium">Posti disponibili</p>
                        <p className="text-slate-400 text-sm">Ultimi biglietti disponibili</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Clock className="w-5 h-5 text-yellow-400" />
                      <div>
                        <p className="text-white font-medium">Durata evento</p>
                        <p className="text-slate-400 text-sm">Dalle {event.time} fino a tardi</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Info Modal */}
      <InfoModal isOpen={isInfoModalOpen} onClose={() => setIsInfoModalOpen(false)} event={event} />
    </div>
  )
}
