"use client"

import { useState, useMemo, useRef, useCallback } from "react"
import { Calendar, MapPin, Music, Instagram, Filter, Search, Clock, Users, Star, Info } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import InteractiveMap from "@/components/interactive-map"
import InfoModal from "@/components/info-modal"
import Link from "next/link"
import { events, categories, genres, cities, type Event } from "@/lib/events"

export default function VibeNowApp() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedGenre, setSelectedGenre] = useState("Tutti")
  const [selectedCategory, setSelectedCategory] = useState("Tutte")
  const [selectedCity, setSelectedCity] = useState("Tutte")
  const [sortBy, setSortBy] = useState("date")
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null)
  const [isInfoModalOpen, setIsInfoModalOpen] = useState(false)

  const eventRefs = useRef<{ [key: number]: HTMLDivElement | null }>({})

  const filteredAndSortedEvents = useMemo(() => {
    const filtered = events.filter((event) => {
      const matchesSearch =
        event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        event.location.toLowerCase().includes(searchTerm.toLowerCase())
      const matchesGenre = selectedGenre === "Tutti" || event.genre === selectedGenre
      const matchesCategory = selectedCategory === "Tutte" || event.category === selectedCategory
      const matchesCity = selectedCity === "Tutte" || event.city === selectedCity

      return matchesSearch && matchesGenre && matchesCategory && matchesCity
    })

    return filtered.sort((a, b) => {
      switch (sortBy) {
        case "date":
          return new Date(a.date).getTime() - new Date(b.date).getTime()
        case "date-desc":
          return new Date(b.date).getTime() - new Date(a.date).getTime()
        case "rating":
          return (b.rating || 0) - (a.rating || 0)
        case "price":
          const priceA = Number.parseInt(a.price?.replace("€", "") || "0")
          const priceB = Number.parseInt(b.price?.replace("€", "") || "0")
          return priceA - priceB
        default:
          return 0
      }
    })
  }, [searchTerm, selectedGenre, selectedCategory, selectedCity, sortBy])

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("it-IT", {
      weekday: "long",
      day: "numeric",
      month: "long",
    })
  }

  const handleEventSelect = useCallback((eventId: number) => {
    // Find the event element and scroll to it
    const eventElement = eventRefs.current[eventId]
    if (eventElement) {
      eventElement.scrollIntoView({
        behavior: "smooth",
        block: "center",
      })

      // Add a highlight effect
      eventElement.style.transform = "scale(1.02)"
      eventElement.style.boxShadow = "0 0 30px rgba(251, 191, 36, 0.5)"

      setTimeout(() => {
        eventElement.style.transform = "scale(1)"
        eventElement.style.boxShadow = ""
      }, 2000)
    }
  }, [])

  const handleInfoClick = (event: Event) => {
    setSelectedEvent(event)
    setIsInfoModalOpen(true)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Header */}
      <header className="sticky top-0 z-50 backdrop-blur-xl bg-slate-950/80 border-b border-yellow-400/20">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col items-center justify-center text-center">
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-black tracking-wider mb-2">
              <span className="bg-gradient-to-r from-yellow-300 via-yellow-400 to-amber-400 bg-clip-text text-transparent animate-pulse drop-shadow-2xl">
                VIBENOW
              </span>
            </h1>
            <div className="flex items-center gap-4">
              <Badge
                variant="outline"
                className="border-yellow-400/70 text-yellow-300 bg-yellow-400/10 backdrop-blur-sm"
              >
                Nightlife Evolution
              </Badge>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section with Interactive Map */}
      <section className="py-12 bg-gradient-to-r from-slate-900 to-slate-800">
        <div className="container mx-auto px-4">
          <div className="text-center mb-8">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Scopri gli Eventi più <span className="text-yellow-400">Hot</span> della Notte
            </h2>
            <p className="text-slate-300 text-lg max-w-2xl mx-auto">
              La tua guida definitiva per la nightlife italiana. Trova i migliori eventi, club e feste nella tua città.
            </p>
          </div>

          <div className="max-w-6xl mx-auto">
            <InteractiveMap
              events={events}
              selectedCategory={selectedCategory}
              selectedGenre={selectedGenre}
              selectedCity={selectedCity}
              onEventSelect={handleEventSelect}
            />
          </div>
        </div>
      </section>

      {/* Filters Section */}
      <section className="py-8 bg-slate-900/50 border-b border-yellow-400/20">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row gap-4 items-center justify-between">
            <div className="flex items-center gap-2 text-yellow-400">
              <Filter className="w-5 h-5" />
              <span className="font-semibold">Filtra Eventi</span>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 w-full lg:w-auto">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                <Input
                  placeholder="Cerca eventi..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-slate-800 border-slate-700 text-white placeholder:text-slate-400 focus:border-yellow-400"
                />
              </div>

              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-full sm:w-[140px] bg-slate-800 border-slate-700 text-white">
                  <SelectValue placeholder="Categoria" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700">
                  {categories.map((category) => (
                    <SelectItem key={category} value={category} className="text-white hover:bg-slate-700">
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={selectedGenre} onValueChange={setSelectedGenre}>
                <SelectTrigger className="w-full sm:w-[140px] bg-slate-800 border-slate-700 text-white">
                  <SelectValue placeholder="Genere" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700">
                  {genres.map((genre) => (
                    <SelectItem key={genre} value={genre} className="text-white hover:bg-slate-700">
                      {genre}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={selectedCity} onValueChange={setSelectedCity}>
                <SelectTrigger className="w-full sm:w-[140px] bg-slate-800 border-slate-700 text-white">
                  <SelectValue placeholder="Città" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700">
                  {cities.map((city) => (
                    <SelectItem key={city} value={city} className="text-white hover:bg-slate-700">
                      {city}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-full sm:w-[160px] bg-slate-800 border-slate-700 text-white">
                  <SelectValue placeholder="Ordina per" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700">
                  <SelectItem value="date" className="text-white hover:bg-slate-700">
                    Data (Prossimi)
                  </SelectItem>
                  <SelectItem value="date-desc" className="text-white hover:bg-slate-700">
                    Data (Lontani)
                  </SelectItem>
                  <SelectItem value="rating" className="text-white hover:bg-slate-700">
                    Rating
                  </SelectItem>
                  <SelectItem value="price" className="text-white hover:bg-slate-700">
                    Prezzo
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </section>

      {/* Events Grid */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="flex overflow-x-auto gap-6 pb-4 md:grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 md:overflow-visible">
            {filteredAndSortedEvents.map((event) => (
              <Card
                key={event.id}
                ref={(el) => (eventRefs.current[event.id] = el)}
                className={`group relative overflow-hidden bg-gradient-to-br from-slate-800 to-slate-900 border-slate-700 hover:border-yellow-400/50 transition-all duration-300 hover:scale-105 hover:shadow-xl hover:shadow-yellow-400/10 flex-shrink-0 w-80 md:w-auto ${
                  event.featured ? "ring-2 ring-yellow-400/30" : ""
                }`}
              >
                {event.featured && (
                  <div className="absolute top-3 right-3 z-10">
                    <Badge className="bg-yellow-400 text-slate-900 font-bold">
                      <Star className="w-3 h-3 mr-1" />
                      Featured
                    </Badge>
                  </div>
                )}

                <Link href={`/event/${event.id}`} className="block">
                  <div className="relative h-48 bg-gradient-to-br from-yellow-400/20 to-slate-800 overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent" />
                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="text-xl font-bold text-white mb-2 line-clamp-2 group-hover:text-yellow-400 transition-colors">
                        {event.title}
                      </h3>
                    </div>
                  </div>

                  <CardContent className="p-4 space-y-3">
                    <div className="flex items-center gap-2 text-slate-300">
                      <Calendar className="w-4 h-4 text-yellow-400" />
                      <span className="text-sm font-medium">{formatDate(event.date)}</span>
                    </div>

                    <div className="flex items-center gap-2 text-slate-300">
                      <Clock className="w-4 h-4 text-yellow-400" />
                      <span className="text-sm">{event.time}</span>
                    </div>

                    <div className="flex items-center gap-2 text-slate-300">
                      <MapPin className="w-4 h-4 text-yellow-400" />
                      <span className="text-sm">
                        {event.location}, {event.city}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 text-slate-300">
                      <Music className="w-4 h-4 text-yellow-400" />
                      <div className="flex gap-1">
                        <Badge
                          variant="secondary"
                          className="bg-slate-700 text-yellow-400 border-yellow-400/30 text-xs"
                        >
                          {event.category}
                        </Badge>
                        <Badge variant="outline" className="border-slate-600 text-slate-300 text-xs">
                          {event.genre}
                        </Badge>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-2">
                      <div className="flex items-center gap-4">
                        {event.price && <span className="text-yellow-400 font-bold text-lg">{event.price}</span>}
                        {event.rating && (
                          <div className="flex items-center gap-1">
                            <Star className="w-4 h-4 text-yellow-400 fill-current" />
                            <span className="text-sm text-slate-300">{event.rating}</span>
                          </div>
                        )}
                      </div>
                      {event.capacity && (
                        <div className="flex items-center gap-1 text-slate-400">
                          <Users className="w-4 h-4" />
                          <span className="text-xs">{event.capacity}</span>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Link>

                <div className="p-4 pt-0">
                  <Button
                    onClick={(e) => {
                      e.preventDefault()
                      handleInfoClick(event)
                    }}
                    className="w-full bg-yellow-400 hover:bg-yellow-500 text-slate-900 font-bold transition-all duration-300 hover:scale-105"
                  >
                    <Info className="w-4 h-4 mr-2" />
                    Più Informazioni
                  </Button>
                </div>
              </Card>
            ))}
          </div>

          {filteredAndSortedEvents.length === 0 && (
            <div className="text-center py-12">
              <div className="text-slate-400 text-lg mb-4">Nessun evento trovato</div>
              <p className="text-slate-500">Prova a modificare i filtri di ricerca</p>
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-950 border-t border-yellow-400/20 py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col items-center gap-6">
            <div className="flex items-center gap-4">
              <a
                href="https://www.instagram.com/vibenow_official?igsh=NjRxZXB3cWIwYm1n&utm_source=qr"
                className="flex items-center gap-2 text-yellow-400 hover:text-yellow-300 transition-colors group"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Instagram className="w-5 h-5 group-hover:scale-110 transition-transform" />
                <span className="font-semibold">@vibenow_official</span>
              </a>
            </div>

            <div className="text-center">
              <p className="text-slate-400 text-sm">© 2025 VibeNow. Tutti i diritti riservati</p>
              <p className="text-slate-500 text-xs mt-1">Nightlife Evolution - La tua guida per la notte italiana</p>
            </div>
          </div>
        </div>
      </footer>

      {/* Info Modal */}
      {selectedEvent && (
        <InfoModal isOpen={isInfoModalOpen} onClose={() => setIsInfoModalOpen(false)} event={selectedEvent} />
      )}
    </div>
  )
}
