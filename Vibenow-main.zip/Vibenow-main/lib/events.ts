// ========================================
// 🎉 CENTRO CONTROLLO EVENTI VIBENOW
// ========================================
// Modifica SOLO questo file per gestire tutti gli eventi!

export interface Event {
  id: number
  title: string
  date: string
  time: string
  location: string
  city: string
  genre: string
  category: string
  price?: string
  capacity?: string
  rating?: number
  featured?: boolean
  lat: number
  lng: number
  description?: string
  organizer?: string
  ageLimit?: string
  dresscode?: string
  highlights?: string[]
}

// ========================================
// 📋 CONFIGURAZIONE FILTRI
// ========================================

export const categories = [
  "Tutte",
  "Nightclub",
  "Beach Club",
  "Rooftop",
  "Aperitivo",
  "Live Music",
  "Sport",
  "Pool Party",
  "Comedy",
  "Karaoke",
]

export const genres = [
  "Tutti",
  "Trap",
  "House",
  "Hip-Hop",
  "Deep House",
  "Indie",
  "Electronic",
  "Reggaeton",
  "Tech House",
  "Jazz",
  "Rock",
  "Latino",
  "Disco",
  "Pop",
  "Calcio",
  "Stand-up",
]

export const cities = [
  "Tutte",
  "Milano",
  "Roma",
  "Catania",
  "Palermo",
]

// ========================================
// 🗺️ COORDINATE CITTÀ (per centrare la mappa)
// ========================================

export const cityCoordinates: { [key: string]: { lat: number; lng: number; zoom: number } } = {
  Milano: { lat: 45.4642, lng: 9.19, zoom: 11 },
  Roma: { lat: 41.9028, lng: 12.4964, zoom: 11 },
  Napoli: { lat: 40.8518, lng: 14.2681, zoom: 11 },
  Torino: { lat: 45.0703, lng: 7.6869, zoom: 11 },
  Firenze: { lat: 43.7696, lng: 11.2558, zoom: 12 },
  Bologna: { lat: 44.4949, lng: 11.3426, zoom: 12 },
  Catania: { lat: 37.5079, lng: 15.083, zoom: 12 },
  Riccione: { lat: 44.0058, lng: 12.6553, zoom: 13 },
  "Milano Marittima": { lat: 44.2897, lng: 12.3468, zoom: 13 },
  Positano: { lat: 40.628, lng: 14.4897, zoom: 14 },
  Sanremo: { lat: 43.8167, lng: 7.7667, zoom: 13 },
  Venezia: { lat: 45.4408, lng: 12.3155, zoom: 12 },
  Palermo: { lat: 38.1157, lng: 13.3613, zoom: 11 },
}

// ========================================
// 🎊 DATABASE EVENTI
// ========================================
// ✨ MODIFICA QUI PER AGGIUNGERE/CAMBIARE EVENTI ✨

export const events: Event[] = [
  // 🌟 EVENTI FEATURED
  {
    id: 1,
    title: "Time Out",
    date: "2025-06-06",
    time: "22:00",
    location: "Casa mia",
    city: "Catania",
    genre: "Trap",
    category: "Nightclub",
    price: "€10",
    capacity: "300",
    rating: 3.0,
    featured: true,
    lat: 37.5079,
    lng: 15.083,
    description:
      "Una serata esplosiva dedicata alla trap italiana e internazionale. I migliori DJ della scena siciliana si alterneranno per una notte indimenticabile alla Villa Dionisio di Catania.",
    organizer: "Villa Dionisio Entertainment",
    ageLimit: "18+",
    dresscode: "Elegante/Casual",
    highlights: ["DJ Set esclusivi", "Drink speciali", "Atmosfera unica", "Pista da ballo professionale"],
  },
    {
    id: 2,
    title: "Finale Champions",
    date: "2025-05-31",
    time: "20:45",
    location: "Le Caveau",
    city: "Catania",
    genre: "Calcio",
    category: "Sport",
    price: "€20",
    capacity: "100",
    rating: 4.7,
    featured: true,
    lat: 36.5079,
    lng: 14.083,
    description:
      "Una serata esplosiva dedicata alla trap italiana e internazionale. I migliori DJ della scena siciliana si alterneranno per una notte indimenticabile alla Villa Dionisio di Catania.",
    organizer: "Villa Dionisio Entertainment",
    ageLimit: "Nessuno",
    dresscode: "Casual",
    highlights: ["DJ Set esclusivi", "Drink speciali", "Atmosfera unica", "Pista da ballo professionale"],
  },
]

// ========================================
// 🛠️ FUNZIONI HELPER
// ========================================

export const getEventById = (id: number): Event | undefined => {
  return events.find((event) => event.id === id)
}

export const getFeaturedEvents = (): Event[] => {
  return events.filter((event) => event.featured)
}

export const getEventsByCategory = (category: string): Event[] => {
  if (category === "Tutte") return events
  return events.filter((event) => event.category === category)
}

export const getEventsByCity = (city: string): Event[] => {
  if (city === "Tutte") return events
  return events.filter((event) => event.city === city)
}
